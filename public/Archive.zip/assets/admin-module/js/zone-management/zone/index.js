"use strict";

$("#zone_form").on('keydown', function (e) {
    if (e.keyCode === 13) {
        e.preventDefault();
    }
})


