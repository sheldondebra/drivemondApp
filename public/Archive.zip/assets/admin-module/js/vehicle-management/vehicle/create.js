"use strict";

$(document).ready(function () {
     $('.model-select').select2({
        placeholder: "Select Model"
    });
});

