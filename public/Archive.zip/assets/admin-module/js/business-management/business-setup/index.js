"use strict";

$('.js-select-lan').select2({
    placeholder: "Select Languages"
});
